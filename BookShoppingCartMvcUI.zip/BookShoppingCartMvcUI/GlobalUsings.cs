﻿global using BookShoppingCartMvcUI.Data;
global using BookShoppingCartMvcUI.Models;
global using BookShoppingCartMvcUI.Models.DTOs;
global using BookShoppingCartMvcUI.Repositories;