using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Project_API.Pages
{
    public class ContactUsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
