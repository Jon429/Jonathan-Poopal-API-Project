using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class ApiPageModel : PageModel
{
    public IActionResult OnGet()
    {
        return new JsonResult(new { message = "Hello from the API!" });
    }
}