using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Project_API
{
    public class InstrumentsModel : PageModel
    {
        public List<Instrument> Instruments { get; set; }
        public void OnGet()
        {
            Instruments = GetInstrumentData();
        }

        private List<Instrument> GetInstrumentData()
        {
            return new List<Instrument>
        {
            new Instrument { Id = 1, Name = "Violin", Price = 250.00, ImageUrl = "~/Images/violin.jpg" },
            new Instrument { Id = 2, Name = "Saxophone", Price = 350.00, ImageUrl = "~/Images/saxophone.jpg" },
            // Add more instruments as needed
        };
        }
    }
}
