using API_Project.Data;
using API_Project.Models;
using Microsoft.AspNetCore.Mvc;
using API_Project.Data;

namespace API_Project.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly DataService _dataService;
        private readonly FileService _fileService;

        public WeatherForecastController(DataService dataService, FileService fileService)
        {
            _dataService = dataService;
            _fileService = fileService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<DataModel>> Get()
        {
            var data = _dataService.GetAllData();
            return Ok(data);
        }

        [HttpPost]
        public ActionResult Post([FromBody] DataModel newData)
        {
            // For simplicity, we're not updating the in-memory database here
            // Instead, we're just adding the data to the file
            var allData = _dataService.GetAllData();
            newData.Id = allData.Count + 1;
            allData.Add(newData);
            _fileService.WriteData(allData);

            return Ok();
        }

        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] DataModel updatedData)
        {
            var existingData = _dataService.GetAllData().FirstOrDefault(d => d.Id == id);
            if (existingData == null)
            {
                return NotFound(); // Return 404 if data with the specified ID is not found
            }

            // Update data in the in-memory database
            _dataService.UpdateData(updatedData);

            // Update data in the file
            var allData = _dataService.GetAllData();
            _fileService.WriteData(allData);

            return Ok();
        }
    }
}
