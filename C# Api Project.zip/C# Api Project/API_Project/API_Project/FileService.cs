﻿using System.Collections.Generic;
using System.IO;
using API_Project.Models;
using Newtonsoft.Json;


namespace API_Project
{
    public class FileService
    {
        private readonly string filePath = "data.json";

        public List<DataModel> ReadData()
        {
            if (File.Exists(filePath))
            {
                var json = File.ReadAllText(filePath);
                return JsonConvert.DeserializeObject<List<DataModel>>(json);
            }
            return new List<DataModel>();
        }

        public void WriteData(List<DataModel> data)
        {
            var json = JsonConvert.SerializeObject(data);
            File.WriteAllText(filePath, json);
        }
    }
}
