﻿using API_Project.Models;
using System.Collections.Generic;

namespace API_Project.Data
{
    public class DataService
    {
        private List<DataModel> _data = new List<DataModel>
    {
        new DataModel { Id = 1, Name = "Item 1" },
        new DataModel { Id = 2, Name = "Item 2" },
        // Add more data as needed
    };

        public List<DataModel> GetAllData()
        {
            return _data;
        }

        public void UpdateData(DataModel updatedData)
        {
            var existingData = _data.FirstOrDefault(d => d.Id == updatedData.Id);
            if (existingData != null)
            {
                existingData.Name = updatedData.Name;
                // Update other properties as needed
            }
        }
    }
}
