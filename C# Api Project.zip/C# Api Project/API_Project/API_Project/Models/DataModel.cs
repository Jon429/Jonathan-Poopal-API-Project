﻿namespace API_Project.Models
{
    public class DataModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
